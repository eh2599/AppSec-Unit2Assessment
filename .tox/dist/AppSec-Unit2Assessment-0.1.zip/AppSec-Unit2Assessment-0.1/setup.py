from distutils.core import setup

setup(
    name='AppSec-Unit2Assessment',
    version='0.1',
)
